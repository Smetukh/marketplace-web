import createAsyncActions from "@letapp/redux-actions/lib/createAsyncActions";

export const initialization = createAsyncActions(
	'app/INITIALIZATION',
);

