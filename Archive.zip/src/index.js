import React from 'react';
import ReactDOM from 'react-dom';
import { Provider, connect } from 'react-redux';
import Router from './scenes/router';
import './styles.css';
import { appOperations } from './modules/app';
import Api from './api';
import store from './store/createStore';

class App extends React.Component {
	constructor(props) {
		super(props);
		props.dispatch(appOperations.init());
	}
	
	// componentDidMount() {
	// fetch('/api/account/user', {
	//     headers: {
	//         Authorization:
	//             'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI1NGFhMjk5MC1kZGUzLTQ0ZjAtOTA4Mi1iMDVhNmFmNGY1MDIiLCJpYXQiOjE1NTk5ODg2ODgwMTB9.vCxO0chPXyMtAc4EjUhIT3O95OFieP_h_O9vPQGO82w',
	//     },
	// })
	//     .then((res) => res.json())
	//     .then(console.log)
	// }

	render() {
		if (this.props.isLoading) {
			return <div>Loading ...</div>; 
		}
		return (
			// <div className="root">
					<Router />
			// </div>
				
		)
	}
}

store.subscribe(() => {
	console.log('State:', {state: store.getState()})
})

function mapStateToProps(state) {
	return {
		isLoading: state.app.isLoading,
	}
}

const AppConnected = connect(mapStateToProps)(App);

ReactDOM.render(
	<Provider store={store}>
		<AppConnected />
	</Provider>, 
	document.getElementById('root'));
