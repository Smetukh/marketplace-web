import React from 'react';
import T from 'prop-types';
import s from './Bookmarks.module.scss';

function Bookmarks() {
	return (
  <div>Bookmarks Component</div>
	)
}

export default Bookmarks;