import React from 'react';
import T from 'prop-types';
import s from './Profile.module.scss';

function Profile() {
	return (
  <div>Profile Component</div>
	)
}

export default Profile;