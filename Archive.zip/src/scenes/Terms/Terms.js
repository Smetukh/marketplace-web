import React from 'react';
import T from 'prop-types';
import s from './Terms.module.scss';

function Terms() {
    return (
        <div>Terms</div>
    )
}

export default Terms;