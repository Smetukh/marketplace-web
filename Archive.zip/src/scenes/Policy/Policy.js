import React from 'react';
import T from 'prop-types';
import s from './Policy.module.scss';

function Policy() {
	return (
  <div>Policy Component</div>
	)
}

export default Policy;