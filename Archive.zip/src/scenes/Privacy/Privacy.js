import React from 'react';
import T from 'prop-types';
import s from './Privacy.module.scss';

function Privacy() {
	return (
  <span className={s.privacy}>Privacy</span>
	)
}

export default Privacy;