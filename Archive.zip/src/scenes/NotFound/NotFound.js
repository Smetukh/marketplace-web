import React from 'react';
import T from 'prop-types';
import s from './NotFound.module.scss';

function NotFound() {
	return (
		<div>Not Found</div>
	)
}

export default NotFound;