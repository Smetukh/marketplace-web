import axios from 'axios';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';

const urls = {
	login: 'api/auth/login',
	register: 'api/auth/register',
}

export const Auth = {
	_token: null,

	get isLoggedIn () {
			return !!this._token;
	},

	setToken(token) {
		
		this._token = token;

		this._storeToken();

		this._setTokenToAxios(token);
	},

	init() {
		try {
			const token = window.localStorage.getItem('token');
			this._token = JSON.parse(token);

			this._setTokenToAxios(token);
			console.log('token, this._token, ', token, this._token)
		} catch(err) {
			console.error(err);
		}
			
	},
	login(body) {
		console.log('urls.login, body = ', urls.login, body);
		const aaa = axios.post(urls.login, body)
		console.log(' axios.post(urls.login, body) = ', aaa)
		return aaa;
	},
	logout() {
		this._token = null;
		try {
			window.localStorage.removeItem('token');
		} catch(err) {
			console.error(err);
		}
	},
	_storeToken() {
		try {
				window.localStorage.setItem('token', JSON.stringify(this._token));
		} catch (err) {
				console.error(err);
		}
	},
	_setTokenToAxios(token) {
		axios.defaults.headers.common.Authorization = `Bearer ${token}`;
	}
	
}

export function init() {
	console.log('initinitinit')
	Auth.init();
}